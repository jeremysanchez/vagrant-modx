<?php
/**
 * Welcome Italian lexicon topic
 *
 * @language it
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'Novità MODX ';
$_lang['security_notices'] = 'Notizie sulla Sicurezza';
$_lang['welcome_messages'] = 'La tua casella di Posta contiene <strong>%d</strong> messaggi(o), di cui <strong>%s</strong> da leggere.';
$_lang['welcome_title'] = 'Benevenuto nel tuo MODX Content Manager';
$_lang['yourinfo_message'] = 'Questa sezione mostra alcune informazioni su di te:';
$_lang['yourinfo_previous_login'] = 'Il tuo ultimo accesso:';
$_lang['yourinfo_title'] = 'Tue Info';
$_lang['yourinfo_total_logins'] = 'Numero totale di accessi:';
$_lang['yourinfo_username'] = 'Sei entrato come:';